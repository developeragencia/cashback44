import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DataTable } from "@/components/ui/data-table";
import { Badge } from "@/components/ui/badge";
import { 
  FileSpreadsheet, 
  Download, 
  Filter,
  Calendar,
  TrendingUp,
  Users,
  Store
} from "lucide-react";

interface ReportFilters {
  startDate: string;
  endDate: string;
  merchantId?: string;
  status: string;
  minAmount?: number;
  maxAmount?: number;
}

interface TransactionReport {
  id: number;
  date: string;
  customer_name: string;
  merchant_name: string;
  amount: number;
  cashback_amount: number;
  status: string;
  payment_method: string;
}

export default function AdminReports() {
  const [filters, setFilters] = useState<ReportFilters>({
    startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0],
    status: 'all'
  });

  const [reportType, setReportType] = useState<'transactions' | 'merchants' | 'customers'>('transactions');

  const { data: reportData, isLoading, refetch } = useQuery({
    queryKey: ['/api/admin/reports', reportType, filters],
    queryFn: async () => {
      const params = new URLSearchParams({
        type: reportType,
        ...filters,
        ...(filters.minAmount && { minAmount: filters.minAmount.toString() }),
        ...(filters.maxAmount && { maxAmount: filters.maxAmount.toString() })
      });

      const response = await fetch(`/api/admin/reports?${params}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error(`Erro ${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    retry: 1,
    staleTime: 2 * 60 * 1000
  });

  const { data: merchants } = useQuery({
    queryKey: ['/api/admin/merchants-list'],
    queryFn: async () => {
      const response = await fetch('/api/admin/merchants?status=approved', {
        credentials: 'include'
      });
      return response.json();
    }
  });

  const exportReport = async (format: 'csv' | 'json') => {
    try {
      const params = new URLSearchParams({
        type: reportType,
        format,
        ...filters,
        ...(filters.minAmount && { minAmount: filters.minAmount.toString() }),
        ...(filters.maxAmount && { maxAmount: filters.maxAmount.toString() })
      });

      const response = await fetch(`/api/admin/reports/export?${params}`, {
        credentials: 'include'
      });

      if (!response.ok) throw new Error('Erro ao exportar relatório');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `relatorio-${reportType}-${new Date().toISOString().split('T')[0]}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Erro ao exportar:', error);
    }
  };

  const transactionColumns = [
    {
      header: "ID",
      accessorKey: "id" as keyof TransactionReport,
    },
    {
      header: "Data",
      accessorKey: "date" as keyof TransactionReport,
      cell: (item: TransactionReport) => new Date(item.date).toLocaleString('pt-BR'),
    },
    {
      header: "Cliente",
      accessorKey: "customer_name" as keyof TransactionReport,
    },
    {
      header: "Loja",
      accessorKey: "merchant_name" as keyof TransactionReport,
    },
    {
      header: "Valor",
      accessorKey: "amount" as keyof TransactionReport,
      cell: (item: TransactionReport) => `R$ ${item.amount.toFixed(2)}`,
    },
    {
      header: "Cashback",
      accessorKey: "cashback_amount" as keyof TransactionReport,
      cell: (item: TransactionReport) => `R$ ${item.cashback_amount.toFixed(2)}`,
    },
    {
      header: "Status",
      accessorKey: "status" as keyof TransactionReport,
      cell: (item: TransactionReport) => (
        <Badge variant={item.status === 'completed' ? 'default' : 'secondary'}>
          {item.status === 'completed' ? 'Concluída' : 'Pendente'}
        </Badge>
      ),
    },
    {
      header: "Pagamento",
      accessorKey: "payment_method" as keyof TransactionReport,
    },
  ];

  const getSummaryStats = () => {
    if (!reportData || !Array.isArray(reportData)) return null;

    const total = reportData.reduce((sum: number, item: any) => sum + (parseFloat(item.amount) || 0), 0);
    const totalCashback = reportData.reduce((sum: number, item: any) => sum + (parseFloat(item.cashback_amount) || 0), 0);
    const platformRevenue = total * 0.05;

    return {
      totalTransactions: reportData.length,
      totalAmount: total,
      totalCashback,
      platformRevenue
    };
  };

  const stats = getSummaryStats();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Relatórios do Sistema</h1>
          <p className="text-muted-foreground">
            Relatórios detalhados e exportação de dados
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => exportReport('csv')}>
            <FileSpreadsheet className="h-4 w-4 mr-2" />
            Exportar CSV
          </Button>
          <Button variant="outline" onClick={() => exportReport('json')}>
            <Download className="h-4 w-4 mr-2" />
            Exportar JSON
          </Button>
        </div>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filtros do Relatório
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-5">
            <div>
              <Label htmlFor="reportType">Tipo de Relatório</Label>
              <Select value={reportType} onValueChange={(value: any) => setReportType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="transactions">Transações</SelectItem>
                  <SelectItem value="merchants">Comerciantes</SelectItem>
                  <SelectItem value="customers">Clientes</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="startDate">Data Inicial</Label>
              <Input
                id="startDate"
                type="date"
                value={filters.startDate}
                onChange={(e) => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
              />
            </div>

            <div>
              <Label htmlFor="endDate">Data Final</Label>
              <Input
                id="endDate"
                type="date"
                value={filters.endDate}
                onChange={(e) => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
              />
            </div>

            {reportType === 'transactions' && (
              <>
                <div>
                  <Label htmlFor="merchant">Comerciante</Label>
                  <Select value={filters.merchantId || 'all'} onValueChange={(value) => 
                    setFilters(prev => ({ ...prev, merchantId: value === 'all' ? undefined : value }))
                  }>
                    <SelectTrigger>
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos os comerciantes</SelectItem>
                      {merchants?.map((merchant: any) => (
                        <SelectItem key={merchant.id} value={merchant.id.toString()}>
                          {merchant.store_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select value={filters.status} onValueChange={(value) => 
                    setFilters(prev => ({ ...prev, status: value }))
                  }>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="completed">Concluídas</SelectItem>
                      <SelectItem value="pending">Pendentes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
          </div>

          <div className="flex gap-2 mt-4">
            <Button onClick={() => refetch()}>
              <TrendingUp className="h-4 w-4 mr-2" />
              Aplicar Filtros
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Estatísticas Resumidas */}
      {stats && (
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Transações</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalTransactions}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Volume Total</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">R$ {stats.totalAmount.toFixed(2)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Cashback Distribuído</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">R$ {stats.totalCashback.toFixed(2)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Receita da Plataforma</CardTitle>
              <Store className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">R$ {stats.platformRevenue.toFixed(2)}</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Tabela de Dados */}
      <Card>
        <CardHeader>
          <CardTitle>Dados do Relatório</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : reportData && Array.isArray(reportData) ? (
            <DataTable
              columns={transactionColumns}
              data={reportData}
              searchKey="customer_name"
            />
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Nenhum dado encontrado para os filtros selecionados</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}