import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/layout/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  ShoppingCart, 
  Plus, 
  Trash2, 
  User, 
  CreditCard,
  DollarSign,
  TrendingUp,
  Package,
  CheckCircle2,
  Loader2,
  Search,
  ArrowRight,
  Gift,
  Users
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

// Interfaces
interface Customer {
  id: number;
  name: string;
  email: string;
  phone: string | null;
  referred_by: number | null;
  referral_code?: string;
}

interface Product {
  id: number;
  name: string;
  price: string | number;
  description?: string;
  category?: string;
  sku?: string;
}

interface CartItem extends Product {
  quantity: number;
}

interface SaleTransaction {
  id: number;
  customer: string;
  date: string;
  amount: number;
  cashback: number;
  payment_method: string;
  status: string;
  description?: string;
  notes?: string;
}

const CASHBACK_RATE = 0.02; // 2%
const REFERRAL_RATE = 0.01; // 1%

// Exchange rate (simplified - in production this would come from an API)
const USD_TO_BRL_RATE = 5.20;

export default function MerchantSales() {
  // States
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [manualAmount, setManualAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState("cash");
  const [discount, setDiscount] = useState<number>(0);
  const [notes, setNotes] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [currency, setCurrency] = useState<'BRL' | 'USD'>('USD');
  
  // Customer search
  const [searchTerm, setSearchTerm] = useState("");
  const [searchBy, setSearchBy] = useState<'name' | 'email' | 'phone'>('name');
  const [customerResults, setCustomerResults] = useState<Customer[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showCustomerDialog, setShowCustomerDialog] = useState(false);
  const [showProductDialog, setShowProductDialog] = useState(false);
  
  const searchTimeoutRef = useRef<NodeJS.Timeout>();
  const { toast } = useToast();

  // Load products
  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ['/api/merchant/products'],
    retry: 1,
    staleTime: 300000 // 5 minutes
  });

  // Load sales
  const { data: sales = [], isLoading: loadingSales, refetch: refetchSales } = useQuery<SaleTransaction[]>({
    queryKey: ['/api/merchant/sales'],
    retry: 1,
    staleTime: 30000 // 30 seconds
  });

  // Register sale mutation
  const registerSaleMutation = useMutation({
    mutationFn: async (saleData: any) => {
      console.log("Enviando dados da venda:", saleData);
      const response = await apiRequest("POST", "/api/merchant/sales", saleData);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `Erro ${response.status}: ${response.statusText}`);
      }
      
      return await response.json();
    },
    onSuccess: (data) => {
      console.log("Venda registrada com sucesso:", data);
      setIsProcessing(false);
      toast({
        title: "✅ Venda Registrada",
        description: `Venda para ${selectedCustomer?.name} processada com sucesso!`,
      });
      resetForm();
      refetchSales();
      queryClient.invalidateQueries({ queryKey: ['/api/merchant/dashboard'] });
    },
    onError: (error: any) => {
      console.error("Erro ao registrar venda:", error);
      setIsProcessing(false);
      toast({
        title: "❌ Erro na Venda",
        description: error.message || "Falha ao processar a venda. Tente novamente.",
        variant: "destructive",
      });
    }
  });

  // Search customers
  useEffect(() => {
    if (searchTerm.length < 2) {
      setCustomerResults([]);
      return;
    }

    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }

    setIsSearching(true);

    searchTimeoutRef.current = setTimeout(async () => {
      try {
        const response = await apiRequest("GET", `/api/merchant/customers?term=${encodeURIComponent(searchTerm)}&searchBy=${searchBy}`);
        const data = await response.json();
        setCustomerResults(Array.isArray(data) ? data : []);
      } catch (error) {
        console.error("Erro ao buscar clientes:", error);
        setCustomerResults([]);
      } finally {
        setIsSearching(false);
      }
    }, 500);

    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current);
      }
    };
  }, [searchTerm, searchBy]);

  // Calculations
  const subtotal = cartItems.reduce((sum, item) => sum + (parseFloat(item.price.toString()) * item.quantity), 0);
  const finalAmount = cartItems.length > 0 ? Math.max(0, subtotal - discount) : Math.max(0, manualAmount - discount);
  const cashbackAmount = finalAmount * CASHBACK_RATE;
  const referralBonus = selectedCustomer?.referred_by ? finalAmount * REFERRAL_RATE : 0;

  // Helper functions
  const formatCurrency = (value: number) => {
    if (currency === 'USD') {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
      }).format(value);
    } else {
      return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
      }).format(value);
    }
  };

  const convertCurrency = (value: number, fromCurrency: 'BRL' | 'USD' = 'BRL') => {
    if (currency === fromCurrency) return value;
    if (currency === 'USD' && fromCurrency === 'BRL') {
      return value / USD_TO_BRL_RATE;
    } else if (currency === 'BRL' && fromCurrency === 'USD') {
      return value * USD_TO_BRL_RATE;
    }
    return value;
  };

  const resetForm = () => {
    setSelectedCustomer(null);
    setCartItems([]);
    setManualAmount(0);
    setPaymentMethod("cash");
    setDiscount(0);
    setNotes("");
  };

  const handleSelectCustomer = (customer: Customer) => {
    setSelectedCustomer(customer);
    setSearchTerm("");
    setCustomerResults([]);
    setShowCustomerDialog(false);
  };

  const handleAddToCart = (product: Product) => {
    const existingIndex = cartItems.findIndex(item => item.id === product.id);
    
    if (existingIndex >= 0) {
      const updatedItems = [...cartItems];
      updatedItems[existingIndex].quantity += 1;
      setCartItems(updatedItems);
    } else {
      setCartItems([...cartItems, { ...product, quantity: 1 }]);
    }
    setShowProductDialog(false);
  };

  const handleRemoveFromCart = (productId: number) => {
    setCartItems(cartItems.filter(item => item.id !== productId));
  };

  const handleUpdateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    
    setCartItems(cartItems.map(item => 
      item.id === productId ? { ...item, quantity: newQuantity } : item
    ));
  };

  const handleSubmitSale = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedCustomer) {
      toast({
        title: "Cliente Obrigatório",
        description: "Selecione um cliente para registrar a venda.",
        variant: "destructive",
      });
      return;
    }

    if (finalAmount <= 0) {
      toast({
        title: "Valor Inválido",
        description: "O valor da venda deve ser maior que zero.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    
    // Convert values to BRL for backend storage (since backend stores in BRL)
    const totalInBRL = currency === 'USD' ? finalAmount * USD_TO_BRL_RATE : finalAmount;
    const subtotalInBRL = currency === 'USD' ? subtotal * USD_TO_BRL_RATE : subtotal;
    const discountInBRL = currency === 'USD' ? discount * USD_TO_BRL_RATE : discount;
    const manualAmountInBRL = currency === 'USD' && manualAmount ? manualAmount * USD_TO_BRL_RATE : manualAmount;

    const saleData = {
      customerId: selectedCustomer.id,
      total: totalInBRL,
      manualAmount: cartItems.length === 0 ? manualAmountInBRL : null,
      paymentMethod,
      notes: notes || `Venda para ${selectedCustomer.name}`,
      subtotal: subtotalInBRL,
      discount: discountInBRL,
      cashback: cashbackAmount * (currency === 'USD' ? USD_TO_BRL_RATE : 1),
      currency: currency,
      items: cartItems.map(item => ({
        productId: item.id,
        quantity: item.quantity,
        price: currency === 'USD' ? parseFloat(item.price.toString()) * USD_TO_BRL_RATE : parseFloat(item.price.toString())
      }))
    };

    console.log("Dados preparados para envio:", saleData);
    registerSaleMutation.mutate(saleData);
  };

  return (
    <DashboardLayout title="Central de Vendas" type="merchant">
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        {/* Currency Selector */}
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800">Central de Vendas</h1>
          <div className="flex items-center space-x-4">
            <Label className="font-medium text-gray-700">Moeda:</Label>
            <Select value={currency} onValueChange={(value: 'BRL' | 'USD') => setCurrency(value)}>
              <SelectTrigger className="w-32 bg-white border-2 border-gray-200">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="BRL">🇧🇷 Real (BRL)</SelectItem>
                <SelectItem value="USD">🇺🇸 Dólar (USD)</SelectItem>
              </SelectContent>
            </Select>
            {currency === 'BRL' && (
              <Badge variant="outline" className="text-xs">
                Taxa: 1 USD = R$ {USD_TO_BRL_RATE.toFixed(2)}
              </Badge>
            )}
          </div>
        </div>

        {/* Header Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100 text-sm font-medium">Vendas Hoje</p>
                  <p className="text-3xl font-bold">{sales.length}</p>
                </div>
                <ShoppingCart className="h-12 w-12 text-green-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100 text-sm font-medium">Faturamento</p>
                  <p className="text-xl font-bold">
                    {formatCurrency(convertCurrency(sales.reduce((sum, sale) => sum + sale.amount, 0)))}
                  </p>
                </div>
                <DollarSign className="h-12 w-12 text-blue-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100 text-sm font-medium">Produtos</p>
                  <p className="text-3xl font-bold">{products.length}</p>
                </div>
                <Package className="h-12 w-12 text-purple-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100 text-sm font-medium">Cashback</p>
                  <p className="text-xl font-bold">
                    {formatCurrency(convertCurrency(sales.reduce((sum, sale) => sum + sale.cashback, 0)))}
                  </p>
                </div>
                <Gift className="h-12 w-12 text-orange-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Sales Form */}
          <div className="lg:col-span-2">
            <Card className="shadow-2xl border-0">
              <CardHeader className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-t-lg">
                <CardTitle className="text-2xl font-bold flex items-center">
                  <Plus className="mr-3 h-6 w-6" />
                  Nova Venda
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                <form onSubmit={handleSubmitSale} className="space-y-6">
                  {/* Customer Selection */}
                  <div className="space-y-3">
                    <Label className="text-lg font-semibold text-gray-700">Cliente</Label>
                    {selectedCustomer ? (
                      <div className="p-4 bg-green-50 border-2 border-green-200 rounded-xl">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h3 className="font-bold text-green-800 text-lg">{selectedCustomer.name}</h3>
                            <p className="text-green-600">{selectedCustomer.email}</p>
                            {selectedCustomer.phone && (
                              <p className="text-green-600">{selectedCustomer.phone}</p>
                            )}
                            {selectedCustomer.referred_by && (
                              <Badge className="mt-2 bg-purple-100 text-purple-700">
                                <Gift className="mr-1 h-3 w-3" />
                                Cliente Indicado (+{REFERRAL_RATE * 100}%)
                              </Badge>
                            )}
                          </div>
                          <Button 
                            type="button" 
                            variant="outline"
                            onClick={() => setSelectedCustomer(null)}
                            className="bg-white hover:bg-gray-50"
                          >
                            Trocar
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <Dialog open={showCustomerDialog} onOpenChange={setShowCustomerDialog}>
                        <DialogTrigger asChild>
                          <Button 
                            type="button" 
                            variant="outline" 
                            className="w-full h-16 text-lg border-2 border-dashed border-gray-300 hover:border-indigo-400 hover:bg-indigo-50"
                          >
                            <User className="mr-3 h-6 w-6" />
                            Selecionar Cliente
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-lg">
                          <DialogHeader>
                            <DialogTitle className="text-xl">Buscar Cliente</DialogTitle>
                          </DialogHeader>
                          
                          <div className="space-y-4">
                            <div className="flex space-x-2">
                              <Select value={searchBy} onValueChange={(value: any) => setSearchBy(value)}>
                                <SelectTrigger className="w-32">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="name">Nome</SelectItem>
                                  <SelectItem value="email">Email</SelectItem>
                                  <SelectItem value="phone">Telefone</SelectItem>
                                </SelectContent>
                              </Select>
                              <div className="relative flex-1">
                                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                                <Input
                                  placeholder="Digite para buscar..."
                                  value={searchTerm}
                                  onChange={(e) => setSearchTerm(e.target.value)}
                                  className="pl-10"
                                />
                              </div>
                            </div>
                            
                            {isSearching && (
                              <div className="flex items-center justify-center py-8">
                                <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
                              </div>
                            )}
                            
                            {customerResults.length > 0 && (
                              <div className="max-h-64 overflow-y-auto space-y-2">
                                {customerResults.map((customer) => (
                                  <div
                                    key={customer.id}
                                    className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                                    onClick={() => handleSelectCustomer(customer)}
                                  >
                                    <div className="flex items-center justify-between">
                                      <div>
                                        <p className="font-medium">{customer.name}</p>
                                        <p className="text-sm text-gray-500">{customer.email}</p>
                                        {customer.phone && (
                                          <p className="text-sm text-gray-500">{customer.phone}</p>
                                        )}
                                      </div>
                                      <ArrowRight className="h-5 w-5 text-gray-400" />
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </DialogContent>
                      </Dialog>
                    )}
                  </div>

                  {/* Products/Manual Amount */}
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <Label className="text-lg font-semibold text-gray-700">
                        Produtos ({cartItems.length})
                      </Label>
                      <Dialog open={showProductDialog} onOpenChange={setShowProductDialog}>
                        <DialogTrigger asChild>
                          <Button type="button" variant="outline" className="bg-indigo-50 hover:bg-indigo-100">
                            <Plus className="mr-2 h-4 w-4" />
                            Adicionar Produto
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>Selecionar Produtos</DialogTitle>
                          </DialogHeader>
                          <div className="max-h-96 overflow-y-auto">
                            <div className="grid gap-3">
                              {products.map((product) => (
                                <div
                                  key={product.id}
                                  className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                                  onClick={() => handleAddToCart(product)}
                                >
                                  <div className="flex justify-between items-center">
                                    <div className="flex-1">
                                      <h4 className="font-medium">{product.name}</h4>
                                      <p className="text-sm text-gray-500">{product.description}</p>
                                    </div>
                                    <div className="text-right">
                                      <p className="font-bold text-lg text-indigo-600">
                                        {formatCurrency(convertCurrency(parseFloat(product.price.toString())))}
                                      </p>
                                      <Plus className="h-5 w-5 text-gray-400 ml-auto mt-1" />
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                    
                    {cartItems.length > 0 ? (
                      <div className="bg-gray-50 border-2 border-gray-200 rounded-xl p-4 space-y-3">
                        {cartItems.map((item) => (
                          <div key={item.id} className="flex items-center justify-between bg-white p-3 rounded-lg shadow-sm">
                            <div className="flex-1">
                              <h4 className="font-medium">{item.name}</h4>
                              <p className="text-sm text-gray-500">
                                {formatCurrency(convertCurrency(parseFloat(item.price.toString())))} cada
                              </p>
                            </div>
                            <div className="flex items-center space-x-3">
                              <div className="flex items-center space-x-2">
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                                  className="h-8 w-8 p-0"
                                >
                                  -
                                </Button>
                                <span className="w-8 text-center font-medium">{item.quantity}</span>
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                                  className="h-8 w-8 p-0"
                                >
                                  +
                                </Button>
                              </div>
                              <div className="text-right">
                                <p className="font-bold">
                                  {formatCurrency(convertCurrency(parseFloat(item.price.toString())) * item.quantity)}
                                </p>
                              </div>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => handleRemoveFromCart(item.id)}
                                className="text-red-500 hover:text-red-700 hover:bg-red-50"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <Label htmlFor="manualAmount" className="text-base font-medium">
                          Valor Manual ({currency === 'USD' ? '$' : 'R$'})
                        </Label>
                        <Input
                          id="manualAmount"
                          type="number"
                          min="0"
                          step="0.01"
                          placeholder="0,00"
                          value={manualAmount || ""}
                          onChange={(e) => setManualAmount(parseFloat(e.target.value) || 0)}
                          className="text-lg h-12"
                        />
                        <p className="text-sm text-gray-500">
                          Use para vendas sem produtos específicos cadastrados
                        </p>
                        {currency === 'BRL' && manualAmount > 0 && (
                          <p className="text-xs text-blue-600">
                            Equivale a $ {(manualAmount / USD_TO_BRL_RATE).toFixed(2)} em dólares
                          </p>
                        )}
                      </div>
                    )}
                  </div>

                  <Separator className="my-6" />

                  {/* Summary */}
                  <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-xl border border-indigo-200">
                    <h3 className="text-lg font-bold text-gray-800 mb-4">Resumo da Venda</h3>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between text-base">
                        <span>Subtotal:</span>
                        <span className="font-medium">
                          {formatCurrency(cartItems.length > 0 ? subtotal : manualAmount)}
                        </span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <Label htmlFor="discount">Desconto:</Label>
                        <Input
                          id="discount"
                          type="number"
                          min="0"
                          step="0.01"
                          value={discount || ""}
                          onChange={(e) => setDiscount(parseFloat(e.target.value) || 0)}
                          className="w-32 text-right"
                          placeholder="0,00"
                        />
                      </div>
                      
                      <div className="flex justify-between text-xl font-bold text-indigo-700">
                        <span>Total:</span>
                        <span>{formatCurrency(finalAmount)}</span>
                      </div>
                      
                      <div className="bg-white p-3 rounded-lg border border-indigo-200">
                        <div className="flex justify-between text-sm">
                          <span className="text-green-600">💰 Cashback Cliente (2%):</span>
                          <span className="font-bold text-green-600">{formatCurrency(cashbackAmount)}</span>
                        </div>
                        {referralBonus > 0 && (
                          <div className="flex justify-between text-sm mt-1">
                            <span className="text-purple-600">🎁 Bônus Indicação (1%):</span>
                            <span className="font-bold text-purple-600">{formatCurrency(referralBonus)}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Payment Method */}
                  <div className="space-y-3">
                    <Label className="text-lg font-semibold text-gray-700">Método de Pagamento</Label>
                    <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                      <SelectTrigger className="h-12 text-base">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">💵 Dinheiro</SelectItem>
                        <SelectItem value="credit_card">💳 Cartão de Crédito</SelectItem>
                        <SelectItem value="debit_card">💳 Cartão de Débito</SelectItem>
                        <SelectItem value="pix">📱 PIX</SelectItem>
                        <SelectItem value="cashback">🎁 Saldo de Cashback</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Notes */}
                  <div className="space-y-3">
                    <Label htmlFor="notes" className="text-base font-medium">Observações</Label>
                    <Input
                      id="notes"
                      placeholder="Observações adicionais (opcional)"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="h-12"
                    />
                  </div>

                  {/* Submit Button */}
                  <Button 
                    type="submit" 
                    className="w-full h-14 text-lg font-bold bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 shadow-lg"
                    disabled={isProcessing || !selectedCustomer || finalAmount <= 0}
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="mr-3 h-6 w-6 animate-spin" />
                        Processando Venda...
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="mr-3 h-6 w-6" />
                        Finalizar Venda • {formatCurrency(finalAmount)}
                      </>
                    )}
                  </Button>
                  
                  {selectedCustomer && finalAmount > 0 && (
                    <Alert className="bg-blue-50 border-blue-200">
                      <AlertDescription className="text-blue-800">
                        ✨ Esta venda gerará <strong>{formatCurrency(cashbackAmount)}</strong> em cashback para {selectedCustomer.name}
                        {referralBonus > 0 && (
                          <span> e <strong>{formatCurrency(referralBonus)}</strong> de bônus para quem indicou</span>
                        )}
                      </AlertDescription>
                    </Alert>
                  )}
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Recent Sales */}
          <div className="lg:col-span-1">
            <Card className="shadow-xl border-0 h-fit">
              <CardHeader className="bg-gradient-to-r from-gray-700 to-gray-800 text-white rounded-t-lg">
                <CardTitle className="flex items-center text-xl">
                  <TrendingUp className="mr-3 h-5 w-5" />
                  Vendas Recentes
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {loadingSales ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                  </div>
                ) : sales.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <ShoppingCart className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                    <p className="text-lg">Nenhuma venda hoje</p>
                    <p className="text-sm">Registre sua primeira venda!</p>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {sales.slice(0, 8).map((sale) => (
                      <div key={sale.id} className="p-4 bg-gray-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <Badge variant="outline" className="text-xs">#{sale.id}</Badge>
                              <Badge className="text-xs bg-green-100 text-green-700">
                                {sale.status}
                              </Badge>
                            </div>
                            <p className="font-medium text-gray-800">{sale.customer}</p>
                            <p className="text-xs text-gray-500 mt-1">{sale.date}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-lg text-gray-800">{formatCurrency(convertCurrency(sale.amount))}</p>
                            <p className="text-xs text-green-600">+{formatCurrency(convertCurrency(sale.cashback))}</p>
                          </div>
                        </div>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>{sale.payment_method}</span>
                          <span className="capitalize">{sale.status}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}